print("Hello,World")

print("Python has 3 numeric types : int, float and complex")

myValue1=1 
print(myValue1)
print(type(myValue1))
print(str(myValue1) + " is of the data type" + str(type(myValue1)))
myValue2=3.14
print(myValue2)
print(type(myValue2))
print(str(myValue2) + " is of the data type" + str(type(myValue2)))
myValue3=5j
print(myValue3)
print(type(myValue3))
print(str(myValue3) + " is of the data type " + str(type(myValue3)))
myValue4=True
print(myValue4)
print(type(myValue4))
myValue5=False
print(myValue5)
print(type(myValue5))
print(str(myValue5) + " is of the data type " + str(type(myValue5)))
myString = "This is a String."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name?")
print(name)
color = input("What is your favorite color?")
animal = input("What is your favorite animal?")
print("{}, you like a {} {}!".format(name,color,animal))
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(type(myFruitList))
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
myFruitList[2] = "orange"
print(myFruitList)
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])
myFavoriteFruitDictionary = {
    "Akua" : "apple",
    "Saanvi": "banana",
    "Paulo": "pineapple"
    }
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])
 